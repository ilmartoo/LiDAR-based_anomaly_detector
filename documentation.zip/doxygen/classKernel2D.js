var classKernel2D =
[
    [ "Kernel2D", "classKernel2D.html#a390659b8579b60799d98c250aa1f8f8c", null ],
    [ "boxOverlap", "classKernel2D.html#adf3609ccae2f187c6b92d6dfc50d94fe", null ]
];