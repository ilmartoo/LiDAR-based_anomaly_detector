var Kernel_8hh =
[
    [ "AbstractKernel", "classAbstractKernel.html", "classAbstractKernel" ],
    [ "Kernel2D", "classKernel2D.html", "classKernel2D" ],
    [ "Kernel3D", "classKernel3D.html", "classKernel3D" ],
    [ "CircularKernel", "classCircularKernel.html", "classCircularKernel" ],
    [ "SphereKernel", "classSphereKernel.html", "classSphereKernel" ],
    [ "SquareKernel", "classSquareKernel.html", "classSquareKernel" ],
    [ "CubeKernel", "classCubeKernel.html", "classCubeKernel" ],
    [ "Kernel_t", "Kernel_8hh.html#abc25fa76f82e39ef554187b096452941", [
      [ "circle", "Kernel_8hh.html#abc25fa76f82e39ef554187b096452941a1155d8992f910feb05ac24fc65521792", null ],
      [ "sphere", "Kernel_8hh.html#abc25fa76f82e39ef554187b096452941ae5d289f4c3b1b59f02e1028751081cb0", null ],
      [ "square", "Kernel_8hh.html#abc25fa76f82e39ef554187b096452941aa3f65e7d51a12b7b234da165931c2728", null ],
      [ "cube", "Kernel_8hh.html#abc25fa76f82e39ef554187b096452941a55c2cbeaa0ff9de0fd83c02ffe5f2aa1", null ]
    ] ],
    [ "kernelFactory", "Kernel_8hh.html#a077e0f13c36ee208d523ccd1fae0849e", null ]
];