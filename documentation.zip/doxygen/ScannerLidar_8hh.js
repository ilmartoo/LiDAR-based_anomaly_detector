var ScannerLidar_8hh =
[
    [ "DeviceItem", "structDeviceItem.html", "structDeviceItem" ],
    [ "ScannerLidar", "classScannerLidar.html", "classScannerLidar" ],
    [ "LOG_DEBUG", "ScannerLidar_8hh.html#a5c01521cd0033d3db4fb914d19865125", null ],
    [ "LOG_ERROR", "ScannerLidar_8hh.html#ad9c73bc78b8b2564e47a037b5a6ca226", null ],
    [ "LOG_FATAL", "ScannerLidar_8hh.html#aa6bb99023313602f9065f1ee56f2b8e0", null ],
    [ "LOG_INFO", "ScannerLidar_8hh.html#a3a355e1f39a113ebe9476236e571e5d8", null ],
    [ "LOG_TRACE", "ScannerLidar_8hh.html#a9119f503eb4eb32e6fd2399f12de067c", null ],
    [ "LOG_WARN", "ScannerLidar_8hh.html#a3dd84b7daa8b86c1dda5d0c9b6e6dc11", null ],
    [ "DeviceState", "ScannerLidar_8hh.html#a0c10345a5a61ea917f59a0437ad481a0", [
      [ "kDeviceStateDisconnect", "ScannerLidar_8hh.html#a0c10345a5a61ea917f59a0437ad481a0a6429cdfcb7e488325b916be41c088182", null ],
      [ "kDeviceStateConnect", "ScannerLidar_8hh.html#a0c10345a5a61ea917f59a0437ad481a0a692f0fa5960f4896a883c366889918b2", null ],
      [ "kDeviceStateSampling", "ScannerLidar_8hh.html#a0c10345a5a61ea917f59a0437ad481a0a3e7a94fbd180b4b70d66c5c0310419fb", null ]
    ] ]
];