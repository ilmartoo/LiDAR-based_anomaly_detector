var ScannerLidar_8hh =
[
    [ "DeviceItem", "structDeviceItem.html", "structDeviceItem" ],
    [ "ScannerLidar", "classScannerLidar.html", "classScannerLidar" ],
    [ "DeviceState", "ScannerLidar_8hh.html#a0c10345a5a61ea917f59a0437ad481a0", [
      [ "kDeviceStateDisconnect", "ScannerLidar_8hh.html#a0c10345a5a61ea917f59a0437ad481a0a6429cdfcb7e488325b916be41c088182", null ],
      [ "kDeviceStateConnect", "ScannerLidar_8hh.html#a0c10345a5a61ea917f59a0437ad481a0a692f0fa5960f4896a883c366889918b2", null ],
      [ "kDeviceStateSampling", "ScannerLidar_8hh.html#a0c10345a5a61ea917f59a0437ad481a0a3e7a94fbd180b4b70d66c5c0310419fb", null ]
    ] ]
];