var classAnomalyReport =
[
    [ "AnomalyReport", "classAnomalyReport.html#a168695189f585fbe66d45551abce25b8", null ],
    [ "~AnomalyReport", "classAnomalyReport.html#a81d801a141daec032f95a19b30d12f41", null ],
    [ "deltaFaces", "classAnomalyReport.html#a3fc8f0c5096f41ea8fb594d9f299704b", null ],
    [ "faceComparisons", "classAnomalyReport.html#a94bc6d19222bd99032b0382e975a4b21", null ],
    [ "generalComparison", "classAnomalyReport.html#aa445823df5e8a8c59381b65360c25bce", null ],
    [ "similar", "classAnomalyReport.html#a759677411cd38258a2aa6099630446e1", null ],
    [ "totalAnomalies", "classAnomalyReport.html#ac813c22a9dc97026f582ca9458bf18a2", null ],
    [ "unmatched", "classAnomalyReport.html#a4e1fd393d78819a2987176ef1c636c44", null ]
];