var classIFileScanner =
[
    [ "IFileScanner", "classIFileScanner.html#a189eaa49c339f814cbc63d5e3dfe8de4", null ],
    [ "~IFileScanner", "classIFileScanner.html#aa16d8a20d2b8d4e6d05dbec3d8b3e11a", null ],
    [ "readData", "classIFileScanner.html#a01b68b5b888e6b378a5cd66ca066d441", null ],
    [ "filename", "classIFileScanner.html#aa16b006184a05f6ff01c103ce377cad5", null ]
];