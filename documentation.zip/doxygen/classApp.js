var classApp =
[
    [ "App", "classApp.html#a23c693cddcbd9f691af15aebe009a335", null ],
    [ "App", "classApp.html#ae3b5ee0724991432fcb3938ddf356a24", null ],
    [ "~App", "classApp.html#a34f1f253b1cef5f4ecbac66eaf6964ec", null ]
];