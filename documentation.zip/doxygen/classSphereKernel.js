var classSphereKernel =
[
    [ "SphereKernel", "classSphereKernel.html#ad92cce52b95decfa99eace7e0d77df14", null ],
    [ "isInside", "classSphereKernel.html#ad747fb3af63f31541f958f19cbb03568", null ]
];