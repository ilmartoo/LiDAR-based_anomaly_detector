var classIScanner =
[
    [ "IScanner", "classIScanner.html#a734dd4baf6ae4bb474565743c708e372", null ],
    [ "~IScanner", "classIScanner.html#a45a7bb2da3646ceac41f910f7a4e6e6a", null ],
    [ "init", "classIScanner.html#aaf3d8b7c70410704054c208f4640a56a", null ],
    [ "isScanning", "classIScanner.html#a70b85bba370c1d2f600983431f5e4767", null ],
    [ "pause", "classIScanner.html#a1e848c86c062444c64de786532d2e493", null ],
    [ "scan", "classIScanner.html#af2da351c6d4cadee6becfda50568eb3b", null ],
    [ "setCallback", "classIScanner.html#aad7319b8ed9aafb5aabdd1c64233d56e", null ],
    [ "stop", "classIScanner.html#a1c5b762bd0a4b6909743f38c614a39f7", null ],
    [ "callback", "classIScanner.html#a22a6008a90243130fcbad5762efced41", null ],
    [ "scanning", "classIScanner.html#afcdf4a93ba2f249ecbad82f504afdbd1", null ]
];