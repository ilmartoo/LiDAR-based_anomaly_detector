var classAbstractKernel =
[
    [ "AbstractKernel", "classAbstractKernel.html#add9a8eff24b335d4f2f848d181f58a75", null ],
    [ "boxOverlap", "classAbstractKernel.html#adfc17b5ffb00f3d19ce6e28c050dff1c", null ],
    [ "isInside", "classAbstractKernel.html#a871534ba8f497da6c33c41129277b0ab", null ],
    [ "makeBox", "classAbstractKernel.html#a353e0879cfd5f56568e5a31a0cc30fd6", null ],
    [ "boxMax", "classAbstractKernel.html#a35646677f2842422ff673b9d7a705373", null ],
    [ "boxMin", "classAbstractKernel.html#a5dcb93b72b203349c5f27ab397d6577e", null ],
    [ "center", "classAbstractKernel.html#a3166dba151fd7d86669d1372a4285f47", null ],
    [ "radius", "classAbstractKernel.html#a45b0c92237ee32acf44478a69e5ebc71", null ]
];