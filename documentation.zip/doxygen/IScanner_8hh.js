var IScanner_8hh =
[
    [ "IScanner", "classIScanner.html", "classIScanner" ],
    [ "ScanCode", "IScanner_8hh.html#a063ad78ae47fb4223135a0f1e862598f", [
      [ "kScanOk", "IScanner_8hh.html#a063ad78ae47fb4223135a0f1e862598fa58da82a59e3826a7feb0586b197ae625", null ],
      [ "kScanEof", "IScanner_8hh.html#a063ad78ae47fb4223135a0f1e862598fa6cde3e5d623162f627171fd8265a42ad", null ],
      [ "kScanError", "IScanner_8hh.html#a063ad78ae47fb4223135a0f1e862598fa5f9ccd41558d22f03faff82904513793", null ]
    ] ]
];