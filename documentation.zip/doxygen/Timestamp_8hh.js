var Timestamp_8hh =
[
    [ "Timestamp", "classTimestamp.html", "classTimestamp" ],
    [ "NANO_DIGITS", "Timestamp_8hh.html#a802d9a32bfac63da3daff409a0232f8b", null ]
];