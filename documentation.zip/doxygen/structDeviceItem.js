var structDeviceItem =
[
    [ "DeviceItem", "structDeviceItem.html#a18ed7dda8cc03f73920d92a6d2be4aa8", null ],
    [ "device_state", "structDeviceItem.html#a42dbb7dc9a11c170e5dc72840479a6ec", null ],
    [ "handle", "structDeviceItem.html#a359d3af9442abd2c6682a121cd8569ab", null ],
    [ "info", "structDeviceItem.html#ae80d7042e0420fd6414c7106cd5310dd", null ]
];