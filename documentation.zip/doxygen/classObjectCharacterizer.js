var classObjectCharacterizer =
[
    [ "ObjectCharacterizer", "classObjectCharacterizer.html#a52e14f8d43c9af19d8920ec1d06e5d0d", null ],
    [ "~ObjectCharacterizer", "classObjectCharacterizer.html#a763cfff460083a486fee463500c09f36", null ],
    [ "defineBackground", "classObjectCharacterizer.html#a32029e7286bf3a7f9bb27a1060fec5b3", null ],
    [ "defineObject", "classObjectCharacterizer.html#a8fb28f671305ed3ff0276e0cde98a135", null ],
    [ "getBackDistance", "classObjectCharacterizer.html#a78d0226fae2812e071b709126f853904", null ],
    [ "getBackFrame", "classObjectCharacterizer.html#ae9da9918669a6a9f3fddf735f43e8ad2", null ],
    [ "getMinReflectivity", "classObjectCharacterizer.html#a6c402efe46e5fb5e26253096f652c337", null ],
    [ "getObjFrame", "classObjectCharacterizer.html#a5761989ae7b494f71dafeeb8b96e5386", null ],
    [ "init", "classObjectCharacterizer.html#aaa7b21119d5d393941fe514f5886ddc6", null ],
    [ "isChrono", "classObjectCharacterizer.html#a192aba3a0f94245c6e3967db4ba6b1e0", null ],
    [ "newPoint", "classObjectCharacterizer.html#a6bb8843dce9f7568a2da2475a7a0dc8c", null ],
    [ "setBackDistance", "classObjectCharacterizer.html#a3b2af72939d197d0faa6361514b46058", null ],
    [ "setBackFrame", "classObjectCharacterizer.html#aed462a7b5e20b27e322f871234e55eab", null ],
    [ "setChrono", "classObjectCharacterizer.html#a776d0a8f3c7b39dcb03f5d034fac2e32", null ],
    [ "setMinReflectivity", "classObjectCharacterizer.html#aad776ad80a11907e6d399f20f8c26cfc", null ],
    [ "setObjFrame", "classObjectCharacterizer.html#a8d83a6285e12d4e43a769c7e3ca94f6f", null ],
    [ "stop", "classObjectCharacterizer.html#ab0353a3531c60c28aca93e9d372e25a7", null ],
    [ "wait", "classObjectCharacterizer.html#a199d161fbddea41871810b4b8b19dc25", null ]
];