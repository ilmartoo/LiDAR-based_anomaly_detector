var classScannerLidar =
[
    [ "init", "classScannerLidar.html#a9e4511a1367fda6796ef9618fda683d3", null ],
    [ "pause", "classScannerLidar.html#ad4786e267fcb24ecc77ad548e7aa9266", null ],
    [ "scan", "classScannerLidar.html#a1416d833388a0031901f15d55e37f8cd", null ],
    [ "setCallback", "classScannerLidar.html#aca72586a19f7904d6e7e19bb255a19c3", null ],
    [ "stop", "classScannerLidar.html#aae7423bf5e8740c34072021438df927f", null ],
    [ "getLidarData", "classScannerLidar.html#ac51c16f8320f8a7d906f48fe39219862", null ],
    [ "lidarConnect", "classScannerLidar.html#a4a569d4577d01a8cd080c1a4f7aa75c9", null ],
    [ "lidarDisConnect", "classScannerLidar.html#a972f1ae9d97118346187d329dec3a9d7", null ],
    [ "lidarStateChange", "classScannerLidar.html#a7aff0339f353ec52ee6db5cce398b083", null ],
    [ "onDeviceBroadcast", "classScannerLidar.html#a5bb7964f163737641dbdc53a4b4e5996", null ],
    [ "onDeviceInfoChange", "classScannerLidar.html#ab5a54f03fd196af2bbac49f5c1937b08", null ],
    [ "onLidarErrorStatusCallback", "classScannerLidar.html#adf9e6375f181f4be2a3699ccfd5d0e24", null ],
    [ "onSampleCallback", "classScannerLidar.html#aeb7bee9e9f273a0fbf8f9e93d7397a06", null ],
    [ "onStopSampleCallback", "classScannerLidar.html#a760fad626d593a9f9772c60800f30a67", null ]
];