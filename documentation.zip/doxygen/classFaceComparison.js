var classFaceComparison =
[
    [ "FaceComparison", "classFaceComparison.html#adf5f6bd355d2929c3cb3bc00774a4a04", null ],
    [ "~FaceComparison", "classFaceComparison.html#a281497702bb000ef264f1a91af102c34", null ],
    [ "modelFace", "classFaceComparison.html#ab79fe6b082cb0de4c5a3450709d8787c", null ],
    [ "objectFace", "classFaceComparison.html#a434f4927dfd5e3251bb346942a6edb8e", null ]
];