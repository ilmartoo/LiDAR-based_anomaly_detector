var classSquareKernel =
[
    [ "SquareKernel", "classSquareKernel.html#adde1363ab9eda11f7efea186b5f8a129", null ],
    [ "isInside", "classSquareKernel.html#adaf272db30e2058eca09f0ca7c0e8562", null ]
];