var classCharacterizedObject =
[
    [ "CharacterizedObject", "classCharacterizedObject.html#a8847183fab967cc97e38d84db246e7f6", null ],
    [ "~CharacterizedObject", "classCharacterizedObject.html#ac72e0d6434b5644157eb4339cd43a768", null ],
    [ "getBBox", "classCharacterizedObject.html#a47813299576ba5d11621598ab368a4bc", null ],
    [ "getFaces", "classCharacterizedObject.html#adb761efeef4574f6717779a05e022ccb", null ],
    [ "numFaces", "classCharacterizedObject.html#ae32f33df702018872e3ce1c4092d109c", null ],
    [ "write", "classCharacterizedObject.html#a2c381538655579d2da1d9ecdf49ec63c", null ],
    [ "writeLivoxCSV", "classCharacterizedObject.html#a9323605444771b8b692c05044f3a7b25", null ]
];