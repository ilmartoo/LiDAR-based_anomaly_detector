var classCharacterizedObject =
[
    [ "CharacterizedObject", "classCharacterizedObject.html#a8847183fab967cc97e38d84db246e7f6", null ],
    [ "~CharacterizedObject", "classCharacterizedObject.html#ac72e0d6434b5644157eb4339cd43a768", null ],
    [ "getBBox", "classCharacterizedObject.html#a47813299576ba5d11621598ab368a4bc", null ],
    [ "getFaces", "classCharacterizedObject.html#adb761efeef4574f6717779a05e022ccb", null ],
    [ "getPoints", "classCharacterizedObject.html#ab802a490aebd03c04f8def2a57f83c18", null ],
    [ "getPoints", "classCharacterizedObject.html#ab9139e22780b9597431064f4554a553c", null ],
    [ "numFaces", "classCharacterizedObject.html#ae32f33df702018872e3ce1c4092d109c", null ],
    [ "setBBox", "classCharacterizedObject.html#a69e671f280aab3fddafff31032077c06", null ],
    [ "setFaces", "classCharacterizedObject.html#a4c1cf2197b211115a5800d3c40a3f63f", null ],
    [ "setPoints", "classCharacterizedObject.html#abac3a79409b40fca57241ec39391b644", null ],
    [ "write", "classCharacterizedObject.html#a2c381538655579d2da1d9ecdf49ec63c", null ],
    [ "writeLivoxCSV", "classCharacterizedObject.html#a9323605444771b8b692c05044f3a7b25", null ]
];