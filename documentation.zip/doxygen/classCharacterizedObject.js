var classCharacterizedObject =
[
    [ "CharacterizedObject", "classCharacterizedObject.html#a8847183fab967cc97e38d84db246e7f6", null ],
    [ "CharacterizedObject", "classCharacterizedObject.html#a7a02a72a27b7cda2f8ab689edfde277c", null ],
    [ "CharacterizedObject", "classCharacterizedObject.html#a71d195304bdf118f45780246859a0a05", null ],
    [ "~CharacterizedObject", "classCharacterizedObject.html#ac72e0d6434b5644157eb4339cd43a768", null ],
    [ "getBBox", "classCharacterizedObject.html#a47813299576ba5d11621598ab368a4bc", null ]
];