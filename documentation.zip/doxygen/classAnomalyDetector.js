var classAnomalyDetector =
[
    [ "AnomalyDetector", "classAnomalyDetector.html#abe960687a6147cbccadc0f681fbf14d9", null ],
    [ "~AnomalyDetector", "classAnomalyDetector.html#a290e2e224cc13e72e733697b1635da9b", null ],
    [ "compare", "classAnomalyDetector.html#a1f5b644fe2f13af82ff41e9e3ee3d76d", null ],
    [ "isChrono", "classAnomalyDetector.html#af646fc5a8feb2dd658ce54781f8c7c1f", null ],
    [ "setChrono", "classAnomalyDetector.html#a72aeadb6cd17fb3239c6c1cd21ffcb60", null ]
];