var Point_8hh =
[
    [ "Point", "classPoint.html", "classPoint" ],
    [ "Vector", "Point_8hh.html#a6960a95f0f447dc75d90d9f3995a200e", null ],
    [ "PointCluster", "Point_8hh.html#ac0b258599bcea72f086e20cc9e6d27e0", [
      [ "cUnclassified", "Point_8hh.html#ac0b258599bcea72f086e20cc9e6d27e0a899fc6e53d2fd078713b20116dab4412", null ],
      [ "cCorePoint", "Point_8hh.html#ac0b258599bcea72f086e20cc9e6d27e0a5fc0edfb8d921a4bc0c20f76e27b1891", null ],
      [ "cBorderPoint", "Point_8hh.html#ac0b258599bcea72f086e20cc9e6d27e0acee4dd3821becfeb4d6b67b66b7b2ce9", null ],
      [ "cNoise", "Point_8hh.html#ac0b258599bcea72f086e20cc9e6d27e0afa38c182d5324fd1f972327cee83c1a1", null ]
    ] ]
];