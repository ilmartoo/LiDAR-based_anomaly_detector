var hierarchy =
[
    [ "AbstractKernel", "classAbstractKernel.html", [
      [ "Kernel2D", "classKernel2D.html", [
        [ "CircularKernel", "classCircularKernel.html", null ],
        [ "SquareKernel", "classSquareKernel.html", null ]
      ] ],
      [ "Kernel3D", "classKernel3D.html", [
        [ "CubeKernel", "classCubeKernel.html", null ],
        [ "SphereKernel", "classSphereKernel.html", null ]
      ] ]
    ] ],
    [ "AnomalyDetector", "classAnomalyDetector.html", null ],
    [ "AnomalyReport", "classAnomalyReport.html", null ],
    [ "BBox", "classBBox.html", null ],
    [ "Box", "classBox.html", null ],
    [ "CharacterizedObject", "classCharacterizedObject.html", null ],
    [ "CLI", "classCLI.html", null ],
    [ "CLICommand", "classCLICommand.html", null ],
    [ "Comparison", "classComparison.html", [
      [ "FaceComparison", "classFaceComparison.html", null ]
    ] ],
    [ "DBScan", "classDBScan.html", null ],
    [ "DeviceItem", "structDeviceItem.html", null ],
    [ "Face", "classFace.html", null ],
    [ "Geometry", "classGeometry.html", null ],
    [ "InputParser", "classInputParser.html", null ],
    [ "IScanner", "classIScanner.html", [
      [ "IFileScanner", "classIFileScanner.html", [
        [ "ScannerCSV", "classScannerCSV.html", null ],
        [ "ScannerLVX", "classScannerLVX.html", null ]
      ] ],
      [ "ScannerLidar", "classScannerLidar.html", null ]
    ] ],
    [ "ObjectCharacterizer", "classObjectCharacterizer.html", null ],
    [ "ObjectManager", "classObjectManager.html", null ],
    [ "Octree", "classOctree.html", null ],
    [ "OctreeMap", "classOctreeMap.html", null ],
    [ "Point", "classPoint.html", [
      [ "LidarPoint", "classLidarPoint.html", null ]
    ] ],
    [ "Timestamp", "classTimestamp.html", null ]
];