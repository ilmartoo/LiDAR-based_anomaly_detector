var searchData=
[
  ['newmodel_134',['newModel',['../classObjectManager.html#a83367bcce05c02914a093e7acfdcc2ab',1,'ObjectManager']]],
  ['newobject_135',['newObject',['../classObjectManager.html#a40d4316e3102bf9576aff55bf6113dde',1,'ObjectManager::newObject(const std::string &amp;objname, const CharacterizedObject &amp;obj)'],['../classObjectManager.html#a5007d8f406a96d9bbd8943cca61caf93',1,'ObjectManager::newObject(const CharacterizedObject &amp;obj)']]],
  ['newpoint_136',['newPoint',['../classObjectCharacterizator.html#a43e83221e8680ec488fe2a56a4afe298',1,'ObjectCharacterizator']]],
  ['numfaces_137',['numFaces',['../classModel.html#add0d8c9d59cffcf6d0bad37898962bea',1,'Model']]],
  ['numparams_138',['numParams',['../classCLICommand.html#aa69b382a53207e5e84504c8d686f89d2',1,'CLICommand']]]
];
