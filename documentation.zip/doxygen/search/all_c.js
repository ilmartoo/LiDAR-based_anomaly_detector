var searchData=
[
  ['newmodel_178',['newModel',['../classObjectManager.html#a36e0b610e491f69fe5f105dd01958e91',1,'ObjectManager']]],
  ['newobject_179',['newObject',['../classObjectManager.html#ab4e8d0533c62b7db61288d7ae0f16151',1,'ObjectManager::newObject(const std::string &amp;objname, const CharacterizedObject &amp;obj)'],['../classObjectManager.html#abdcffa6ef25c748721405ab22bed2dae',1,'ObjectManager::newObject(const CharacterizedObject &amp;obj)']]],
  ['newpoint_180',['newPoint',['../classObjectCharacterizer.html#a6bb8843dce9f7568a2da2475a7a0dc8c',1,'ObjectCharacterizer']]],
  ['normals_181',['normals',['../classDBScan.html#a5bcea5947de8d39e015222d79f622cbb',1,'DBScan']]],
  ['numfaces_182',['numFaces',['../classCharacterizedObject.html#ae32f33df702018872e3ce1c4092d109c',1,'CharacterizedObject']]],
  ['numparams_183',['numParams',['../classCLICommand.html#aa69b382a53207e5e84504c8d686f89d2',1,'CLICommand']]]
];
