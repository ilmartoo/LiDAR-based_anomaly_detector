var searchData=
[
  ['info_498',['info',['../structDeviceItem.html#ae80d7042e0420fd6414c7106cd5310dd',1,'DeviceItem']]],
  ['instance_499',['instance',['../classIScanner.html#a091e69188252e4d67968aac5b27f1497',1,'IScanner']]]
];
