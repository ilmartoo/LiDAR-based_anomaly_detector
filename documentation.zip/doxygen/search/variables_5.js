var searchData=
[
  ['numfaces_400',['numFaces',['../classModel.html#add0d8c9d59cffcf6d0bad37898962bea',1,'Model']]]
];
