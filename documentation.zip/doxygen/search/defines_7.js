var searchData=
[
  ['mageta_578',['mageta',['../string__format_8h.html#a239e5bb2af966d7aa65eb8c70d36b8e7',1,'mageta():&#160;string_format.h'],['../string__format_8h.html#aa8fd2bcba429e629c6b2bd334ca9b19f',1,'MAGETA():&#160;string_format.h']]]
];
