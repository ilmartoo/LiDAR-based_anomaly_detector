var searchData=
[
  ['italic_574',['ITALIC',['../string__format_8h.html#af706885b9b3eb2821dff28f8e7f7bb3f',1,'ITALIC():&#160;string_format.h'],['../string__format_8h.html#a239f3146859efbf7dc59f7bd478b66ec',1,'italic():&#160;string_format.h']]]
];
