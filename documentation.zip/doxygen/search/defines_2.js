var searchData=
[
  ['darkgrey_565',['darkgrey',['../string__format_8h.html#a7b4c18f6a8448554b43ebc52454c0b85',1,'darkgrey():&#160;string_format.h'],['../string__format_8h.html#ae275d21d0f9d8bb065e6706921c132d9',1,'DARKGREY():&#160;string_format.h']]]
];
