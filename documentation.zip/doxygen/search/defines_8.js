var searchData=
[
  ['purple_573',['PURPLE',['../string__format_8h.html#a0bb0b009e7a7390473ace4d98bd843c0',1,'PURPLE():&#160;string_format.h'],['../string__format_8h.html#aa150e725f4e80f62a1505877c0c17381',1,'purple():&#160;string_format.h']]]
];
