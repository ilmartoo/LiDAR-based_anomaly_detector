var searchData=
[
  ['deltafaces_481',['deltaFaces',['../classAnomalyReport.html#a3fc8f0c5096f41ea8fb594d9f299704b',1,'AnomalyReport']]],
  ['deltas_482',['deltas',['../classComparison.html#a982a4358df13496f3cad49b9b7dbc660',1,'Comparison']]],
  ['device_5fstate_483',['device_state',['../structDeviceItem.html#a42dbb7dc9a11c170e5dc72840479a6ec',1,'DeviceItem']]]
];
