var searchData=
[
  ['characterizedobject_347',['CharacterizedObject',['../classCharacterizedObject.html#a8847183fab967cc97e38d84db246e7f6',1,'CharacterizedObject']]],
  ['cli_348',['CLI',['../classCLI.html#ab9607f70dd951f9a5ee6bf2c157b0900',1,'CLI::CLI(const std::string &amp;filename, ChronoMode chronoMode, uint32_t objFrame, uint32_t backFrame, float minReflectivity, float backDistance)'],['../classCLI.html#ad98a309225ac3f7f158ca73a591f8964',1,'CLI::CLI(const char *broadcastCode, ChronoMode chronoMode, uint32_t objFrame, uint32_t backFrame, float minReflectivity, float backDistance)']]],
  ['clusters_349',['clusters',['../classDBScan.html#a6dbc847f09d27167cafd5429c1c6ce7a',1,'DBScan']]],
  ['compare_350',['compare',['../classAnomalyDetector.html#a1f5b644fe2f13af82ff41e9e3ee3d76d',1,'AnomalyDetector']]],
  ['comparison_351',['Comparison',['../classComparison.html#a133bc81ad6d1bf2a6df50858fb75eeda',1,'Comparison']]],
  ['computecentroid_352',['computeCentroid',['../classGeometry.html#af3824089a41cdff0e16a0cab9962c6e7',1,'Geometry::computeCentroid(const std::vector&lt; Point &gt; &amp;points)'],['../classGeometry.html#a2d8e49eef32c098a28de6bee1a14ea1b',1,'Geometry::computeCentroid(const std::vector&lt; Point * &gt; &amp;points)']]],
  ['computenormal_353',['computeNormal',['../classGeometry.html#ae61a4061402e2ee74c55d50541bf5248',1,'Geometry::computeNormal(const std::vector&lt; Point &gt; &amp;points)'],['../classGeometry.html#ae6496d8c273565712a961894fd556a28',1,'Geometry::computeNormal(const std::vector&lt; Point * &gt; &amp;points)']]],
  ['computenormals_354',['computeNormals',['../classGeometry.html#ad8da1f75e490fd365ec27eda5e5062af',1,'Geometry']]],
  ['computeplane_355',['computePlane',['../classGeometry.html#aba4b51ad63ecd1a746e57ca4cd1e6d32',1,'Geometry::computePlane(const Vector &amp;vnormal, const Point &amp;centroid)'],['../classGeometry.html#a48bb961f35b81ad110bc334156dfd5e2',1,'Geometry::computePlane(const std::vector&lt; Point &gt; &amp;points)'],['../classGeometry.html#a82cba4aa850c6c93d76b258af2b125ef',1,'Geometry::computePlane(const std::vector&lt; Point * &gt; &amp;points)']]],
  ['create_356',['create',['../classIFileScanner.html#a3aabd912af40f987a17044fe45be4ec5',1,'IFileScanner::create()'],['../classIScanner.html#a00fb32a2aefaccb85a9caf8147b5f4f3',1,'IScanner::create()'],['../classScannerCSV.html#ad856aeb5d4fcce4015e9387b2898b135',1,'ScannerCSV::create()'],['../classScannerLidar.html#a42231266db0be62b90948edfac0d2d48',1,'ScannerLidar::create()'],['../classScannerLVX.html#a8ea8cdc892fd898c74a8a3161f19e940',1,'ScannerLVX::create()']]],
  ['crossproduct_357',['crossProduct',['../classPoint.html#a73570bcfad1f4e6fa6d8fcebf752708c',1,'Point']]],
  ['csv_358',['CSV',['../classLidarPoint.html#af1568d9b349b465c0df9c0d1d6876cf3',1,'LidarPoint']]]
];
