var searchData=
[
  ['scancode_512',['ScanCode',['../IScanner_8hh.html#a063ad78ae47fb4223135a0f1e862598f',1,'IScanner.hh']]]
];
