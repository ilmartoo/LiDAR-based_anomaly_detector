var searchData=
[
  ['face_364',['Face',['../classFace.html#afdb634bc2d5287ba0d62e46b57e9dc2e',1,'Face::Face()'],['../classFace.html#aab37166a5c05f2384fed4c34f2c7af1e',1,'Face::Face(const std::vector&lt; size_t &gt; &amp;indices, const Vector &amp;normal, const BBox &amp;minBBox, const Vector &amp;minBBoxRotAngles)']]],
  ['facecomparison_365',['FaceComparison',['../classFaceComparison.html#adf5f6bd355d2929c3cb3bc00774a4a04',1,'FaceComparison']]]
];
