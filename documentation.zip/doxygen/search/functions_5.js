var searchData=
[
  ['face_361',['Face',['../classFace.html#afdb634bc2d5287ba0d62e46b57e9dc2e',1,'Face::Face()'],['../classFace.html#a6243fb5ffdda7147ac3e81512b5a45cd',1,'Face::Face(const std::vector&lt; Point &gt; &amp;points, const Vector &amp;normal, const BBox &amp;minBBox, const Vector &amp;minBBoxRotAngles)']]],
  ['facecomparison_362',['FaceComparison',['../classFaceComparison.html#adf5f6bd355d2929c3cb3bc00774a4a04',1,'FaceComparison']]]
];
