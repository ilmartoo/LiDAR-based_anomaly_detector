var searchData=
[
  ['white_579',['white',['../string__format_8h.html#a91b13a0f429317b47cbbcb8fe3e0191a',1,'white():&#160;string_format.h'],['../string__format_8h.html#a87b537f5fa5c109d3c05c13d6b18f382',1,'WHITE():&#160;string_format.h']]]
];
