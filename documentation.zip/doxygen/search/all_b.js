var searchData=
[
  ['mageta_174',['mageta',['../string__format_8h.html#a239e5bb2af966d7aa65eb8c70d36b8e7',1,'mageta():&#160;string_format.h'],['../string__format_8h.html#aa8fd2bcba429e629c6b2bd334ca9b19f',1,'MAGETA():&#160;string_format.h']]],
  ['mean_175',['mean',['../classGeometry.html#a354959ce8f1deddb3e38d3fbb0c1d37f',1,'Geometry::mean(const std::vector&lt; Point &gt; &amp;points)'],['../classGeometry.html#a1b088348b39759a0351d64f8ea4355ca',1,'Geometry::mean(const std::vector&lt; Point * &gt; &amp;points)']]],
  ['minimumbbox_176',['minimumBBox',['../classGeometry.html#abf95632ef54da7df73c4453accc876a1',1,'Geometry::minimumBBox(const std::vector&lt; Point &gt; &amp;points)'],['../classGeometry.html#ae2479d3a81991610c9ffa2bc2079324e',1,'Geometry::minimumBBox(const std::vector&lt; std::vector&lt; Point &gt;&gt; &amp;points)']]],
  ['minimumbboxrottrans_177',['minimumBBoxRotTrans',['../classGeometry.html#a1d2311cda8900f4cd327a69b1b9aa6dd',1,'Geometry']]],
  ['model_178',['Model',['../CharacterizedObject_8hh.html#afe59560be594ba46a7c55081a3a307c5',1,'CharacterizedObject.hh']]],
  ['modelface_179',['modelFace',['../classFaceComparison.html#ab79fe6b082cb0de4c5a3450709d8787c',1,'FaceComparison']]],
  ['module_180',['module',['../classPoint.html#ab620fad8adda239b46b050861d20ae7f',1,'Point']]]
];
