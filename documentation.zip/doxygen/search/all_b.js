var searchData=
[
  ['mageta_170',['mageta',['../string__format_8h.html#a239e5bb2af966d7aa65eb8c70d36b8e7',1,'mageta():&#160;string_format.h'],['../string__format_8h.html#aa8fd2bcba429e629c6b2bd334ca9b19f',1,'MAGETA():&#160;string_format.h']]],
  ['mean_171',['mean',['../classGeometry.html#a354959ce8f1deddb3e38d3fbb0c1d37f',1,'Geometry::mean(const std::vector&lt; Point &gt; &amp;points)'],['../classGeometry.html#a1b088348b39759a0351d64f8ea4355ca',1,'Geometry::mean(const std::vector&lt; Point * &gt; &amp;points)']]],
  ['minimumbbox_172',['minimumBBox',['../classGeometry.html#abf95632ef54da7df73c4453accc876a1',1,'Geometry']]],
  ['minimumbboxes_173',['minimumBBoxes',['../classGeometry.html#a97ea2f1a42d6e2f805a1d0489365069f',1,'Geometry']]],
  ['minimumbboxrottrans_174',['minimumBBoxRotTrans',['../classGeometry.html#a354d36a89681a7c8dfebec1527c8b4c6',1,'Geometry']]],
  ['model_175',['Model',['../CharacterizedObject_8hh.html#afe59560be594ba46a7c55081a3a307c5',1,'CharacterizedObject.hh']]],
  ['modelface_176',['modelFace',['../classFaceComparison.html#ab79fe6b082cb0de4c5a3450709d8787c',1,'FaceComparison']]],
  ['module_177',['module',['../classPoint.html#ab620fad8adda239b46b050861d20ae7f',1,'Point']]]
];
