var searchData=
[
  ['definebackground_359',['defineBackground',['../classObjectCharacterizer.html#a32029e7286bf3a7f9bb27a1060fec5b3',1,'ObjectCharacterizer']]],
  ['defineobject_360',['defineObject',['../classObjectCharacterizer.html#a8fb28f671305ed3ff0276e0cde98a135',1,'ObjectCharacterizer']]],
  ['distance3d_361',['distance3D',['../classPoint.html#af33ae10b17d8fa785a05c574ddcd82de',1,'Point']]]
];
