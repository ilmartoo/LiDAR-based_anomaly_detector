var searchData=
[
  ['definebackground_279',['defineBackground',['../classObjectCharacterizator.html#a5c7532a869b5dbddf8970af9b4613b66',1,'ObjectCharacterizator']]],
  ['defineobject_280',['defineObject',['../classObjectCharacterizator.html#a36c0f7502362c028b562c224f6a8c9e3',1,'ObjectCharacterizator']]],
  ['distance3d_281',['distance3D',['../classPoint.html#af33ae10b17d8fa785a05c574ddcd82de',1,'Point']]]
];
