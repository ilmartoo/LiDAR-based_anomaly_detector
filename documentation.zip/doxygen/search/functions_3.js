var searchData=
[
  ['definebackground_356',['defineBackground',['../classObjectCharacterizator.html#a5c7532a869b5dbddf8970af9b4613b66',1,'ObjectCharacterizator']]],
  ['defineobject_357',['defineObject',['../classObjectCharacterizator.html#a530468c3d2734c716acb7b4b58cfbd02',1,'ObjectCharacterizator']]],
  ['distance3d_358',['distance3D',['../classPoint.html#af33ae10b17d8fa785a05c574ddcd82de',1,'Point']]]
];
