var searchData=
[
  ['objectface_491',['objectFace',['../classFaceComparison.html#a434f4927dfd5e3251bb346942a6edb8e',1,'FaceComparison']]]
];
