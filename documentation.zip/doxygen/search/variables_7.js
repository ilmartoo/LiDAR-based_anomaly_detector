var searchData=
[
  ['xradius_402',['xradius',['../classAnomalies.html#acce24de8662cdea4656e8934a61c0a25',1,'Anomalies']]]
];
