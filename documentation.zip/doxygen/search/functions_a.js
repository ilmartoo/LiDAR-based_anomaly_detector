var searchData=
[
  ['mean_414',['mean',['../classGeometry.html#a354959ce8f1deddb3e38d3fbb0c1d37f',1,'Geometry::mean(const std::vector&lt; Point &gt; &amp;points)'],['../classGeometry.html#a1b088348b39759a0351d64f8ea4355ca',1,'Geometry::mean(const std::vector&lt; Point * &gt; &amp;points)']]],
  ['minimumbbox_415',['minimumBBox',['../classGeometry.html#abf95632ef54da7df73c4453accc876a1',1,'Geometry']]],
  ['minimumbboxes_416',['minimumBBoxes',['../classGeometry.html#a97ea2f1a42d6e2f805a1d0489365069f',1,'Geometry']]],
  ['minimumbboxrottrans_417',['minimumBBoxRotTrans',['../classGeometry.html#a354d36a89681a7c8dfebec1527c8b4c6',1,'Geometry']]],
  ['module_418',['module',['../classPoint.html#ab620fad8adda239b46b050861d20ae7f',1,'Point']]]
];
