var searchData=
[
  ['kernel2d_301',['Kernel2D',['../classKernel2D.html',1,'']]],
  ['kernel3d_302',['Kernel3D',['../classKernel3D.html',1,'']]]
];
