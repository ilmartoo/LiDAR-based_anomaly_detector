var searchData=
[
  ['skyblue_583',['SKYBLUE',['../string__format_8h.html#af4afc6cd7b5f51b03339fb49e76c60f0',1,'SKYBLUE():&#160;string_format.h'],['../string__format_8h.html#a9ae7ca936ccfc47fa34a7b7aee7a8d5d',1,'skyblue():&#160;string_format.h']]],
  ['steelblue_584',['STEELBLUE',['../string__format_8h.html#a2ac57f37e3c657282f1c17adc24d414f',1,'STEELBLUE():&#160;string_format.h'],['../string__format_8h.html#a3a7a979c67d6a969607dc372d73b4fb4',1,'steelblue():&#160;string_format.h']]]
];
