var searchData=
[
  ['face_298',['Face',['../classFace.html',1,'']]],
  ['facecomparison_299',['FaceComparison',['../classFaceComparison.html',1,'']]]
];
