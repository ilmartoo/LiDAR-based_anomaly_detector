var searchData=
[
  ['face_295',['Face',['../classFace.html',1,'']]],
  ['facecomparison_296',['FaceComparison',['../classFaceComparison.html',1,'']]]
];
