var searchData=
[
  ['yellow_270',['yellow',['../string__format_8h.html#aca448042424756708b030b145d69f834',1,'yellow():&#160;string_format.h'],['../string__format_8h.html#abf681265909adf3d3e8116c93c0ba179',1,'YELLOW():&#160;string_format.h']]]
];
