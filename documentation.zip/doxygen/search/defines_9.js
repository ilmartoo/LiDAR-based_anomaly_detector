var searchData=
[
  ['red_574',['RED',['../string__format_8h.html#a8d23feea868a983c8c2b661e1e16972f',1,'RED():&#160;string_format.h'],['../string__format_8h.html#aaf213b6c71119b03c7f518535a144902',1,'red():&#160;string_format.h']]],
  ['reset_575',['RESET',['../string__format_8h.html#ab702106cf3b3e96750b6845ded4e0299',1,'string_format.h']]],
  ['reversed_576',['reversed',['../string__format_8h.html#a736abfb7020da30f1ec5ba0f5778eec6',1,'reversed():&#160;string_format.h'],['../string__format_8h.html#ac9bc3fb6eddd8f12dbedee55c7644816',1,'REVERSED():&#160;string_format.h']]]
];
