var searchData=
[
  ['kernel2d_233',['Kernel2D',['../classKernel2D.html',1,'']]],
  ['kernel3d_234',['Kernel3D',['../classKernel3D.html',1,'']]]
];
