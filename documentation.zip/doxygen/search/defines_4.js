var searchData=
[
  ['green_567',['green',['../string__format_8h.html#adbe40d02fb98cfcf9904e2a6888c6624',1,'green():&#160;string_format.h'],['../string__format_8h.html#acfbc006ea433ad708fdee3e82996e721',1,'GREEN():&#160;string_format.h']]]
];
