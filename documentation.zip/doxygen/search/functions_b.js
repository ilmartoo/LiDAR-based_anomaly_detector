var searchData=
[
  ['newmodel_414',['newModel',['../classObjectManager.html#a36e0b610e491f69fe5f105dd01958e91',1,'ObjectManager']]],
  ['newobject_415',['newObject',['../classObjectManager.html#ab4e8d0533c62b7db61288d7ae0f16151',1,'ObjectManager::newObject(const std::string &amp;objname, const CharacterizedObject &amp;obj)'],['../classObjectManager.html#abdcffa6ef25c748721405ab22bed2dae',1,'ObjectManager::newObject(const CharacterizedObject &amp;obj)']]],
  ['newpoint_416',['newPoint',['../classObjectCharacterizator.html#a43e83221e8680ec488fe2a56a4afe298',1,'ObjectCharacterizator']]],
  ['normals_417',['normals',['../classDBScan.html#ade29e18d3a4bc75913a1ffbab359fdf7',1,'DBScan']]],
  ['numfaces_418',['numFaces',['../classCharacterizedObject.html#ae32f33df702018872e3ce1c4092d109c',1,'CharacterizedObject']]],
  ['numparams_419',['numParams',['../classCLICommand.html#aa69b382a53207e5e84504c8d686f89d2',1,'CLICommand']]]
];
