var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwy~",
  1: "abcdfgiklopst",
  2: "abcdfgiklopst",
  3: "abcdefghilmnoprstvw~",
  4: "cdfghimostu",
  5: "mv",
  6: "cdps",
  7: "cdk",
  8: "glo",
  9: "bcdfgilmprswy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros"
};

