var searchData=
[
  ['handle_497',['handle',['../structDeviceItem.html#a359d3af9442abd2c6682a121cd8569ab',1,'DeviceItem']]]
];
