var searchData=
[
  ['modelface_490',['modelFace',['../classFaceComparison.html#ab79fe6b082cb0de4c5a3450709d8787c',1,'FaceComparison']]]
];
