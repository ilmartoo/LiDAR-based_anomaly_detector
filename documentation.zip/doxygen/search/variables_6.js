var searchData=
[
  ['scanning_401',['scanning',['../classIScanner.html#afcdf4a93ba2f249ecbad82f504afdbd1',1,'IScanner']]]
];
