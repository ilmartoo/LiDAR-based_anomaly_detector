var searchData=
[
  ['readdata_164',['readData',['../classIFileScanner.html#a01b68b5b888e6b378a5cd66ca066d441',1,'IFileScanner']]]
];
