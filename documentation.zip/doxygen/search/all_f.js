var searchData=
[
  ['readdata_215',['readData',['../classIFileScanner.html#a01b68b5b888e6b378a5cd66ca066d441',1,'IFileScanner']]],
  ['red_216',['RED',['../string__format_8h.html#a8d23feea868a983c8c2b661e1e16972f',1,'RED():&#160;string_format.h'],['../string__format_8h.html#aaf213b6c71119b03c7f518535a144902',1,'red():&#160;string_format.h']]],
  ['reset_217',['RESET',['../string__format_8h.html#ab702106cf3b3e96750b6845ded4e0299',1,'string_format.h']]],
  ['reversed_218',['reversed',['../string__format_8h.html#a736abfb7020da30f1ec5ba0f5778eec6',1,'reversed():&#160;string_format.h'],['../string__format_8h.html#ac9bc3fb6eddd8f12dbedee55c7644816',1,'REVERSED():&#160;string_format.h']]],
  ['rotate_219',['rotate',['../classPoint.html#acf6618e378adefe1a10e9750545dfe88',1,'Point']]],
  ['rotationmatrix_220',['rotationMatrix',['../classGeometry.html#a3a772b1e0e78716b8dbd87458fbe949c',1,'Geometry::rotationMatrix(int xdeg, int ydeg, int zdeg)'],['../classGeometry.html#acacf482d7bcf95780c99cd279526e64c',1,'Geometry::rotationMatrix(const Vector &amp;deg)']]]
];
