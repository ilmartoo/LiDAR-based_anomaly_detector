var searchData=
[
  ['facecomparisons_494',['faceComparisons',['../classAnomalyReport.html#a94bc6d19222bd99032b0382e975a4b21',1,'AnomalyReport']]],
  ['filename_495',['filename',['../classIFileScanner.html#aa16b006184a05f6ff01c103ce377cad5',1,'IFileScanner']]]
];
