var searchData=
[
  ['zradius_208',['zradius',['../classAnomalies.html#ab04ea8cf9a068cc91d5fda4568e7021f',1,'Anomalies']]]
];
