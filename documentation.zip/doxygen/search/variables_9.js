var searchData=
[
  ['totalanomalies_504',['totalAnomalies',['../classAnomalyReport.html#ac813c22a9dc97026f582ca9458bf18a2',1,'AnomalyReport']]]
];
