var searchData=
[
  ['callback_480',['callback',['../classIScanner.html#a22a6008a90243130fcbad5762efced41',1,'IScanner']]]
];
