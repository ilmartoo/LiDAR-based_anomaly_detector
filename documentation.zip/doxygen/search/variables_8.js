var searchData=
[
  ['scanning_492',['scanning',['../classIScanner.html#afcdf4a93ba2f249ecbad82f504afdbd1',1,'IScanner']]],
  ['similar_493',['similar',['../classAnomalyReport.html#a759677411cd38258a2aa6099630446e1',1,'AnomalyReport::similar()'],['../classComparison.html#a32f457de6850a5eca1065bd03bb2fca3',1,'Comparison::similar()']]]
];
