var searchData=
[
  ['yradius_403',['yradius',['../classAnomalies.html#a669f402efd1307aaf9b826c7c85e171e',1,'Anomalies']]]
];
