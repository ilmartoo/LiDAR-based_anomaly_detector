var classComparison =
[
    [ "Comparison", "classComparison.html#a133bc81ad6d1bf2a6df50858fb75eeda", null ],
    [ "~Comparison", "classComparison.html#ad0692d49c402128a09dbbd5139af202d", null ],
    [ "deltas", "classComparison.html#a982a4358df13496f3cad49b9b7dbc660", null ],
    [ "similar", "classComparison.html#a32f457de6850a5eca1065bd03bb2fca3", null ]
];