var classAnomalies =
[
    [ "Anomalies", "classAnomalies.html#ac8b26c1cb9b08a6fcc3931f28a919da3", null ],
    [ "face", "classAnomalies.html#aab9e2811c5067739a4ab4bb6c4137104", null ],
    [ "xradius", "classAnomalies.html#acce24de8662cdea4656e8934a61c0a25", null ],
    [ "yradius", "classAnomalies.html#a669f402efd1307aaf9b826c7c85e171e", null ],
    [ "zradius", "classAnomalies.html#ab04ea8cf9a068cc91d5fda4568e7021f", null ]
];