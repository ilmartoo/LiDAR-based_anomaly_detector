var classScannerCSV =
[
    [ "init", "classScannerCSV.html#ad772a78f5d40937335b0090c7f429164", null ],
    [ "pause", "classScannerCSV.html#a0869ec2b62f2bb3c9db32ba4fdd94397", null ],
    [ "scan", "classScannerCSV.html#aceac5ebf997936de8c8bf2fbf76b520e", null ],
    [ "setCallback", "classScannerCSV.html#a878269cc850273e094ea86f135935181", null ],
    [ "stop", "classScannerCSV.html#a155dcac1831680fddb113f6dc5731705", null ]
];