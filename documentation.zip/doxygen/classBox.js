var classBox =
[
    [ "Box", "classBox.html#ab72b920b857775e3f5d3394519c95d61", null ],
    [ "isInside", "classBox.html#a854cf7b2a2d3a44b4aa4dc58f0e1d72a", null ],
    [ "max", "classBox.html#aa673acef2d4b92fa310309ecadabfd8b", null ],
    [ "maxX", "classBox.html#a13244d3e717c1fda7a2c21ce16bff6d4", null ],
    [ "maxY", "classBox.html#ac4c576f334da513d9f6c310d257164a2", null ],
    [ "maxZ", "classBox.html#a6c1519fb6f4f9945cbfb03f8e1301e4f", null ],
    [ "min", "classBox.html#a446b4012fba470ee2c8c75a56dee130b", null ],
    [ "minX", "classBox.html#a67a5542b621e96a68f5c18b4b351a58e", null ],
    [ "minY", "classBox.html#a3bb77abe4f63a58b0f01ed348223f491", null ],
    [ "minZ", "classBox.html#a36706ef0f001d90125d253f1f03fbde4", null ]
];