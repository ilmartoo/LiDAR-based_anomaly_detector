var classScannerLVX =
[
    [ "init", "classScannerLVX.html#a33b997d59223a7e55352aca850b9f86a", null ],
    [ "pause", "classScannerLVX.html#a9fcf6e6ad6b777802e68dda629e4f217", null ],
    [ "scan", "classScannerLVX.html#a3d6a1a1d94b7d1297aafa3861f687017", null ],
    [ "setCallback", "classScannerLVX.html#a4e39faf3dffefc5f368852894655f119", null ],
    [ "stop", "classScannerLVX.html#abeb7a0372e79ee042a84a09eda7e167a", null ]
];