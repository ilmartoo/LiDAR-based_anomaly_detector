var dir_e6a46eaf5f0c8c3e11609743177702c5 =
[
    [ "CharacterizedObject.hh", "CharacterizedObject_8hh.html", "CharacterizedObject_8hh" ],
    [ "DBScan.hh", "DBScan_8hh.html", [
      [ "DBScan", "classDBScan.html", null ]
    ] ],
    [ "Face.hh", "Face_8hh.html", [
      [ "Face", "classFace.html", "classFace" ]
    ] ],
    [ "ObjectCharacterizer.hh", "ObjectCharacterizer_8hh.html", "ObjectCharacterizer_8hh" ]
];