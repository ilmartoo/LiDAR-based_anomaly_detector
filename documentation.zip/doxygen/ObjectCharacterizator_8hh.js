var ObjectCharacterizator_8hh =
[
    [ "ObjectCharacterizator", "classObjectCharacterizator.html", "classObjectCharacterizator" ],
    [ "CharacterizatorState", "ObjectCharacterizator_8hh.html#ae373ece3c85f34e5238907e07cc81048", [
      [ "defBackground", "ObjectCharacterizator_8hh.html#ae373ece3c85f34e5238907e07cc81048a9bf51127c6134aec44249625da9783cf", null ],
      [ "defObject", "ObjectCharacterizator_8hh.html#ae373ece3c85f34e5238907e07cc81048a6730e1dad21e899dd3cc46f4c81e4b87", null ],
      [ "defDiscard", "ObjectCharacterizator_8hh.html#ae373ece3c85f34e5238907e07cc81048a99423877cc033facaa1537ff88990fcf", null ],
      [ "defStopped", "ObjectCharacterizator_8hh.html#ae373ece3c85f34e5238907e07cc81048a9a398574fb7364701a9c44d91908189a", null ]
    ] ]
];