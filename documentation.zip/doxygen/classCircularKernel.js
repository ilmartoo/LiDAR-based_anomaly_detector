var classCircularKernel =
[
    [ "CircularKernel", "classCircularKernel.html#ad53f763620575a50afa4839b46f8b526", null ],
    [ "isInside", "classCircularKernel.html#a4d0cc93770f73a772f56dec135778593", null ]
];