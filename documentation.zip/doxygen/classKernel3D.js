var classKernel3D =
[
    [ "Kernel3D", "classKernel3D.html#ac76fc5efbe4566f43e17e9a8951de140", null ],
    [ "boxOverlap", "classKernel3D.html#a90023829dc6d2b1bc1c0152214901d3e", null ]
];