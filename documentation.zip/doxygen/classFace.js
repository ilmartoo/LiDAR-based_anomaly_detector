var classFace =
[
    [ "Face", "classFace.html#afdb634bc2d5287ba0d62e46b57e9dc2e", null ],
    [ "Face", "classFace.html#a6243fb5ffdda7147ac3e81512b5a45cd", null ],
    [ "~Face", "classFace.html#a182c8c9ba652d46b01fdf6816cd65590", null ],
    [ "getMinBBox", "classFace.html#ad47c3c411888ba00a1f5144c44721eba", null ],
    [ "getMinBBoxRotAngles", "classFace.html#ac94faf09e053ad6b189ac2733a82d5e9", null ],
    [ "getNormal", "classFace.html#a68be304e52e9a4971a6ddae9c08fefc6", null ],
    [ "getPoints", "classFace.html#af3ff70dcc758565758ef078e70f8bac7", null ]
];