var classFace =
[
    [ "Face", "classFace.html#afdb634bc2d5287ba0d62e46b57e9dc2e", null ],
    [ "Face", "classFace.html#aab37166a5c05f2384fed4c34f2c7af1e", null ],
    [ "~Face", "classFace.html#a182c8c9ba652d46b01fdf6816cd65590", null ],
    [ "getIndices", "classFace.html#acf0862e38b2a7aa8222e254fdf3b5e0c", null ],
    [ "getMinBBox", "classFace.html#ad47c3c411888ba00a1f5144c44721eba", null ],
    [ "getMinBBoxRotAngles", "classFace.html#ac94faf09e053ad6b189ac2733a82d5e9", null ],
    [ "getNormal", "classFace.html#a68be304e52e9a4971a6ddae9c08fefc6", null ]
];