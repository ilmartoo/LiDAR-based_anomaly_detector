var classObjectCharacterizator =
[
    [ "ObjectCharacterizator", "classObjectCharacterizator.html#a9ae12d88109301cacfc91c6bf254b227", null ],
    [ "~ObjectCharacterizator", "classObjectCharacterizator.html#ae61faf8145e1a30d42283df512f6e86d", null ],
    [ "defineBackground", "classObjectCharacterizator.html#a5c7532a869b5dbddf8970af9b4613b66", null ],
    [ "defineObject", "classObjectCharacterizator.html#a36c0f7502362c028b562c224f6a8c9e3", null ],
    [ "getBackDistance", "classObjectCharacterizator.html#a1107722cdd16b635dea07f0dc516e778", null ],
    [ "getBackFrame", "classObjectCharacterizator.html#af6d41cc97944bd8c69115be3cf2bff7e", null ],
    [ "getMinReflectivity", "classObjectCharacterizator.html#adb38d3cef646e2c294cb11520c6b7c51", null ],
    [ "getObjFrame", "classObjectCharacterizator.html#ad1cbf21e997d392cca7cba7a2ae92345", null ],
    [ "init", "classObjectCharacterizator.html#a418320f3b5244f3ac8acc20fed116e4f", null ],
    [ "isChrono", "classObjectCharacterizator.html#a8dc158225661d72a6b0e79a572db205a", null ],
    [ "newPoint", "classObjectCharacterizator.html#a43e83221e8680ec488fe2a56a4afe298", null ],
    [ "setBackDistance", "classObjectCharacterizator.html#acf6bb0d513c96a05027e8c3279c2d016", null ],
    [ "setBackFrame", "classObjectCharacterizator.html#ae3c9bad8215d272cc883fe9f1ecc8170", null ],
    [ "setChrono", "classObjectCharacterizator.html#ad4f57b8ac5d2d7019ec6425fc6daed14", null ],
    [ "setMinReflectivity", "classObjectCharacterizator.html#a422dd4bbef594d729de528475e0043d3", null ],
    [ "setObjFrame", "classObjectCharacterizator.html#a8479168884d1d884b562cdc074ad68fd", null ],
    [ "stop", "classObjectCharacterizator.html#a5dac3cde05bb85d4a9aa0ad48d4bf954", null ],
    [ "wait", "classObjectCharacterizator.html#a0a9c034cd23b430c6d5233944155cc46", null ]
];